import sys

print >>sys.stdout, 'Hello World'
print >>sys.stdout, 1, 2, 3
print >>sys.stdout, 1, 2, 3,
print >>sys.stdout
