class MyClass:
    def method(self, i):
        if i is 5:
            print('five')
        elif i is not 2:
            print('not two')
        else:
            print('2')
