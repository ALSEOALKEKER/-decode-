def foo(a, b, c):
    return c - (a + b) 

def bar(a, b, c, d):
    return a / ((b ** c) * d)

def baz(a, b, c, d):
    return a - ((b ^ c) + d)
